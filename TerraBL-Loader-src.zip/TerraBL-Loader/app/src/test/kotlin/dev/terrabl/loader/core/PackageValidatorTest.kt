package dev.terrabl.loader.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Assume.assumeTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class PackageValidatorTest {
    @get:Rule val tmp = TemporaryFolder()

    private fun expectFail(code: String, block: () -> Unit) {
        try { block(); fail("esperaba PackageException($code)") } catch (e: PackageException) { assertEquals(code, e.code) }
    }

    @Test fun validV2() {
        val r = PackageValidator.inspect(TestZips.v2(tmp.newFile("a.bl")))
        assertEquals(BlKind.V2_JS, r.kind); assertEquals("demo", r.manifest.id); assertEquals(1, r.jsFiles)
    }

    @Test fun validV3IsDetectedAndWarned() {
        val r = PackageValidator.inspect(TestZips.v3(tmp.newFile("b.bl")))
        assertEquals(BlKind.V3_CSHARP, r.kind)
        assertTrue(r.warnings.any { "runtime C#" in it })
    }

    @Test fun zipSlipRejected() {
        val f = TestZips.zip(tmp.newFile("c.bl"), mapOf("manifest.json" to TestZips.manifest(), "content/main.js" to "x", "../evil.txt" to "x"))
        expectFail("zip-slip") { PackageValidator.inspect(f) }
    }

    @Test fun absoluteAndBackslashRejected() {
        expectFail("zip-path") { PackagePaths.safeEntryName("/etc/passwd") }
        expectFail("zip-path") { PackagePaths.safeEntryName("a\\b") }
        expectFail("zip-path") { PackagePaths.safeEntryName("C:/x") }
    }

    @Test fun notZip() {
        val f = tmp.newFile("d.bl"); f.writeBytes(byteArrayOf(0xef.toByte(), 0xbb.toByte(), 0xbf.toByte(), 0x7b))
        expectFail("not-zip") { PackageValidator.inspect(f) }
    }

    @Test fun missingManifest() {
        val f = TestZips.zip(tmp.newFile("e.bl"), mapOf("content/main.js" to "x"))
        expectFail("no-manifest") { PackageValidator.inspect(f) }
    }

    @Test fun v2WithoutEntryRejected() {
        val f = TestZips.zip(tmp.newFile("f.bl"), mapOf("manifest.json" to TestZips.manifest()))
        expectFail("v2-entry") { PackageValidator.inspect(f) }
    }

    @Test fun unsupportedBlVersion() {
        val f = TestZips.zip(tmp.newFile("g.bl"), mapOf("manifest.json" to TestZips.manifest(bl = 1)))
        expectFail("manifest-blversion") { PackageValidator.inspect(f) }
    }

    @Test fun limitsEnforced() {
        val f = TestZips.v2(tmp.newFile("h.bl"))
        expectFail("zip-total") { PackageValidator.inspect(f, PackageLimits(maxTotalBytes = 10)) }
    }

    @Test fun unresolvedImportIsWarning() {
        val f = TestZips.v2(tmp.newFile("i.bl"), mainJs = "import { X } from './missing.js';\nexport default class M extends Mod {}")
        assertTrue(PackageValidator.inspect(f).warnings.any { "sin resolver" in it })
    }

    @Test fun resolveRelative() {
        assertEquals("content/Common/A.js", PackageValidator.resolveRelative("content/main.js", "./Common/A.js"))
        assertEquals("content/B.js", PackageValidator.resolveRelative("content/Common/A.js", "../B.js"))
        assertEquals(null, PackageValidator.resolveRelative("content/main.js", "../../x.js"))
    }

    /** Caso real: el mod entregado por el usuario (se copia sin modificar a testdata/). */
    @Test fun realArkOfTheCosmos() {
        val f = File("../testdata/arkofthecosmos.bl")
        assumeTrue(f.exists())
        val r = PackageValidator.inspect(f)
        assertEquals(BlKind.V2_JS, r.kind)
        assertEquals("arkofthecosmos", r.manifest.id)
        assertEquals("1.12.7", r.manifest.version)
        assertEquals(56, r.jsFiles)
        assertEquals(121, r.entryCount)
        assertTrue("icono declarado inexistente debe avisarse", r.warnings.any { "icon.png" in it })
        assertTrue("todos los imports del mod resuelven", r.warnings.none { "sin resolver" in it })
    }
}
