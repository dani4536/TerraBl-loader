package dev.terrabl.loader.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class ModStoreTest {
    @get:Rule val tmp = TemporaryFolder()
    private lateinit var root: File
    private lateinit var store: ModStore

    @Before fun setUp() { root = tmp.newFolder("root"); store = ModStore(root) }

    private fun install(id: String = "demo", mainJs: String = "export default class M extends Mod {}", replace: Boolean = false): InstalledMod {
        val f = TestZips.v2(File(tmp.root, "$id-${System.nanoTime()}.bl"), id, mainJs)
        return store.install(f, PackageValidator.inspect(f), replace)
    }

    @Test fun installIsDisabledByDefaultAndExtracted() {
        val m = install()
        assertFalse(m.enabled)
        assertTrue(File(store.dirOf(m), "content/main.js").isFile)
        assertEquals(1, store.list().size)
    }

    @Test fun sameFileIsDuplicate() {
        val f = TestZips.v2(File(tmp.root, "x.bl"))
        val r = PackageValidator.inspect(f)
        store.install(f, r)
        assertEquals(DuplicateKind.SAME_FILE, store.findDuplicate(r).first)
        try { store.install(f, r, replace = true); fail() } catch (e: PackageException) { assertEquals("duplicate", e.code) }
    }

    @Test fun otherContentNeedsConfirmAndKeepsBackup() {
        install(mainJs = "// v1")
        try { install(mainJs = "// v2 distinto"); fail() } catch (e: PackageException) { assertEquals("duplicate", e.code) }
        install(mainJs = "// v2 distinto", replace = true)
        assertEquals(1, store.list().size)
        assertEquals(1, File(root, "backups").listFiles()!!.size)
    }

    @Test fun enableDisableRemove() {
        val m = install()
        store.setEnabled(m.key, true); assertTrue(store.list().single().enabled)
        store.setEnabled(m.key, false); assertFalse(store.list().single().enabled)
        store.remove(m.key)
        assertTrue(store.list().isEmpty()); assertFalse(File(root, "mods/${m.dir}").exists())
        assertEquals(1, File(root, "backups").listFiles()!!.size)
    }

    @Test fun profilesApplyEnabledSet() {
        val a = install("a"); val b = install("b")
        store.setEnabled(a.key, true); store.saveProfile("solo-a")
        store.setEnabled(b.key, true); store.setEnabled(a.key, false)
        store.applyProfile("solo-a")
        assertEquals(setOf(a.key), store.list().filter { it.enabled }.map { it.key }.toSet())
    }

    @Test fun staleStateEntriesAreDropped() {
        val m = install()
        File(root, "mods/${m.dir}").deleteRecursively()
        assertTrue(store.list().isEmpty())
    }

    @Test fun extractRejectsEscapingPaths() {
        val f = TestZips.zip(File(tmp.root, "slip.bl"), mapOf("../evil.txt" to "x"))
        try { store.extractSafely(f, File(tmp.root, "out")); fail() } catch (e: PackageException) { assertEquals("zip-slip", e.code) }
        assertFalse(File(tmp.root, "evil.txt").exists())
    }
}
