package dev.terrabl.loader.core

import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object TestZips {
    fun manifest(id: String = "demo", bl: Int = 2, extra: String = "") =
        """{"uid":"${"%08x".format(id.hashCode())}-0000-4000-8000-000000000000","id":"$id","name":"Demo $id","version":"1.0.0","blVersion":$bl,"entry":"main.js"$extra}"""

    fun zip(file: File, files: Map<String, String>): File {
        ZipOutputStream(file.outputStream()).use { z ->
            files.forEach { (n, c) -> z.putNextEntry(ZipEntry(n)); z.write(c.toByteArray()); z.closeEntry() }
        }
        return file
    }

    fun v2(file: File, id: String = "demo", mainJs: String = "export default class M extends Mod { Load(){} }") =
        zip(file, mapOf("manifest.json" to manifest(id), "content/main.js" to mainJs))

    fun v3(file: File, id: String = "demo") =
        zip(file, mapOf("manifest.json" to manifest(id, 3), "$id.cs" to "class X {}"))
}
