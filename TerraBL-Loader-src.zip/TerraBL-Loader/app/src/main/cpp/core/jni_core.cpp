// Nucleo nativo ARM32. En esta etapa SOLO expone informacion verificable.
// No hay hooks, ni QuickJS, ni IL2CPP todavia: ver ARCHITECTURE.md y TODO.md.
#include <jni.h>
#include <android/log.h>
#include "core/error.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "TerraBL", __VA_ARGS__)

namespace {
const char* compiledAbi() {
#if defined(__arm__)
    return "armeabi-v7a";
#elif defined(__aarch64__)
    return "arm64-v8a";
#elif defined(__i386__)
    return "x86";
#elif defined(__x86_64__)
    return "x86_64";
#else
    return "unknown";
#endif
}
}  // namespace

extern "C" {

JNIEXPORT jstring JNICALL
Java_dev_terrabl_loader_NativeCore_nativeAbi(JNIEnv* env, jobject) {
    return env->NewStringUTF(compiledAbi());
}

JNIEXPORT jint JNICALL
Java_dev_terrabl_loader_NativeCore_nativePointerBits(JNIEnv*, jobject) {
    return static_cast<jint>(sizeof(void*) * 8);
}

// Motores: devuelven NotImplemented hasta que existan de verdad.
JNIEXPORT jint JNICALL
Java_dev_terrabl_loader_NativeCore_nativeStartJsEngine(JNIEnv*, jobject) {
    LOGI("JS engine solicitado: no implementado");
    return static_cast<jint>(terrabl::Err::NotImplemented);
}

JNIEXPORT jint JNICALL
Java_dev_terrabl_loader_NativeCore_nativeStartCsharpRuntime(JNIEnv*, jobject) {
    LOGI("C# runtime solicitado: no implementado");
    return static_cast<jint>(terrabl::Err::NotImplemented);
}

}  // extern "C"
