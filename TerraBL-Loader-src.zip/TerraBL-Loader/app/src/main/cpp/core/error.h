#pragma once
// Codigos de error compartidos entre C++ y Kotlin (ver NativeCore.kt).
namespace terrabl {
enum class Err : int {
    Ok = 0,
    NotImplemented = 1,   // la funcion existe en la API pero aun no tiene implementacion
    WrongAbi = 2,
    OutOfMemory = 3,
    BadArgument = 4,
};
const char* errName(Err e);
}  // namespace terrabl
