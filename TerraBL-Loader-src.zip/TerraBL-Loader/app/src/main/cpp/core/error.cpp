#include "core/error.h"
namespace terrabl {
const char* errName(Err e) {
    switch (e) {
        case Err::Ok: return "ok";
        case Err::NotImplemented: return "not-implemented";
        case Err::WrongAbi: return "wrong-abi";
        case Err::OutOfMemory: return "out-of-memory";
        case Err::BadArgument: return "bad-argument";
    }
    return "unknown";
}
}  // namespace terrabl
