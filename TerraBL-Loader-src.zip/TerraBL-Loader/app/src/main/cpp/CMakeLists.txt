cmake_minimum_required(VERSION 3.22)
project(terrabl CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_VISIBILITY_PRESET hidden)

# Falla pronto si alguien intenta compilar para otra ABI: el proyecto es ARM32.
if(NOT ANDROID_ABI STREQUAL "armeabi-v7a")
  message(FATAL_ERROR "TerraBL Loader solo se compila para armeabi-v7a (recibido: ${ANDROID_ABI})")
endif()

add_library(terrabl SHARED
    core/jni_core.cpp
    core/error.cpp)
target_include_directories(terrabl PRIVATE ${CMAKE_CURRENT_SOURCE_DIR})
target_compile_options(terrabl PRIVATE -O2 -Wall -Wextra)
target_link_libraries(terrabl log)

# --- Etapas siguientes (ver TODO.md), NO incluidas todavia ---
# QuickJS (BL v2):  third_party/quickjs/  -> add_library(quickjs STATIC ...)
# Hook engine ARMv7 (Thumb-2/ARM) + IL2CPP bridge: solo tras tener Terraria ARM32 que analizar.
