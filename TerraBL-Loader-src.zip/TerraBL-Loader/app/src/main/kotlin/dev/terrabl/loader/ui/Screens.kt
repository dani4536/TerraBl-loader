package dev.terrabl.loader.ui

import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.terrabl.loader.NativeCore
import dev.terrabl.loader.core.BlKind
import dev.terrabl.loader.core.DuplicateKind
import dev.terrabl.loader.core.InstalledMod

private val Scheme = darkColorScheme(
    primary = Color(0xFF6FE3A5), onPrimary = Color(0xFF003822),
    background = Color(0xFF0F1512), surface = Color(0xFF16201B),
    surfaceVariant = Color(0xFF1F2C25), onSurface = Color(0xFFE2EDE6),
    onSurfaceVariant = Color(0xFFB4C4BA), error = Color(0xFFFF8A80),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TerraBlApp(vm: AppViewModel) {
    MaterialTheme(colorScheme = Scheme) {
        var tab by remember { mutableIntStateOf(0) }
        val snack = remember { SnackbarHostState() }
        LaunchedEffect(vm.message) { vm.message?.let { snack.showSnackbar(it); vm.message = null } }
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    listOf(
                        "Inicio" to Icons.Default.Home, "Mods" to Icons.Default.Build,
                        "Archivos" to Icons.Default.Add, "Ajustes" to Icons.Default.Settings,
                    ).forEachIndexed { i, (label, icon) ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i },
                            icon = { Icon(icon, label) }, label = { Text(label) })
                    }
                }
            },
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> HomeScreen(vm)
                    1 -> ModsScreen(vm)
                    2 -> FilesScreen(vm)
                    else -> SettingsScreen(vm)
                }
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

// ------------------------------------------------------------------ INICIO
@Composable
private fun HomeScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val t = remember { vm.terrariaInfo() }
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("TerraBL Loader", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Gestor de mods .bl para Terraria Mobile (ARM32)", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Section("Terraria") {
            if (t.installed) {
                Text("Instalado · versión ${t.versionName}")
                Text("ABI del juego: ${t.abi}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else Text("No se detecta Terraria (${AppViewModel.TERRARIA_PKG}).")
        }
        Section("Mods") {
            Text("${vm.mods.size} instalados · ${vm.mods.count { it.enabled }} activados")
        }
        Section("Estado del motor") {
            Text("Núcleo nativo: " + if (NativeCore.loaded) "cargado (${NativeCore.abi()}, ${NativeCore.pointerBits()} bits)" else "no cargado")
            Text("Motor JS (BL v2): no implementado", color = MaterialTheme.colorScheme.error)
            Text("Runtime C# (BL v3): no implementado", color = MaterialTheme.colorScheme.error)
            Text("Integración con Terraria: no disponible", color = MaterialTheme.colorScheme.error)
        }
        Button(onClick = { confirm = true }, enabled = t.installed, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text("Iniciar Terraria (sin mods)")
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Iniciar Terraria") },
        text = { Text("Terraria se abrirá SIN modificar: TerraBL todavía no puede inyectar mods en el juego.") },
        confirmButton = {
            TextButton(onClick = {
                confirm = false
                ctx.packageManager.getLaunchIntentForPackage(AppViewModel.TERRARIA_PKG)?.let {
                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(it)
                } ?: run { vm.message = "No se pudo abrir Terraria" }
            }) { Text("Abrir") }
        },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancelar") } },
    )
}

// -------------------------------------------------------------------- MODS
@Composable
private fun ModsScreen(vm: AppViewModel) {
    var info by remember { mutableStateOf<InstalledMod?>(null) }
    var del by remember { mutableStateOf<InstalledMod?>(null) }
    var newProfile by remember { mutableStateOf(false) }
    var profName by remember { mutableStateOf("") }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Perfiles", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                vm.profiles.profiles.keys.sorted().forEach { n ->
                    FilterChip(selected = vm.profiles.active == n, onClick = { vm.applyProfile(n) }, label = { Text(n) })
                }
                OutlinedButton(onClick = { newProfile = true }) { Text("+ Guardar") }
            }
            if (vm.profiles.active.isNotEmpty()) TextButton(onClick = { vm.deleteProfile(vm.profiles.active) }) {
                Text("Borrar perfil «${vm.profiles.active}»")
            }
        }
        if (vm.mods.isEmpty()) item { Text("No hay mods instalados. Impórtalos en Archivos.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(vm.mods, key = { it.key }) { m ->
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(m.name, fontWeight = FontWeight.SemiBold)
                            Text("v${m.version} · ${m.kind.label}", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = m.enabled, onCheckedChange = { vm.toggle(m, it) })
                    }
                    if (m.enabled && m.kind == BlKind.V3_CSHARP) {
                        Text("Activado, pero no se ejecuta: falta el runtime C# ARM32.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    } else if (m.enabled) {
                        Text("Activado, pero no se ejecuta: falta la integración con Terraria.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                    Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                        IconButton(onClick = { info = m }) { Icon(Icons.Default.Info, "Información") }
                        IconButton(onClick = { del = m }) { Icon(Icons.Default.Delete, "Eliminar") }
                    }
                }
            }
        }
    }
    info?.let { m ->
        AlertDialog(onDismissRequest = { info = null }, confirmButton = { TextButton(onClick = { info = null }) { Text("Cerrar") } },
            title = { Text(m.name) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("id: ${m.id}\nuid: ${m.uid.ifEmpty { "—" }}\nversión: ${m.version}\ntipo: ${m.kind.label}")
                    Text("autores: ${m.authors.joinToString().ifEmpty { "—" }}")
                    Text("tamaño: ${m.sizeBytes / 1024} KB\nsha256: ${m.sha256.take(16)}…")
                    if (m.summary.isNotEmpty()) Text("\n${m.summary}")
                }
            })
    }
    del?.let { m ->
        AlertDialog(onDismissRequest = { del = null }, title = { Text("Eliminar ${m.name}") },
            text = { Text("Se guarda una copia de seguridad antes de borrarlo.") },
            confirmButton = { TextButton(onClick = { vm.remove(m); del = null }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("Cancelar") } })
    }
    if (newProfile) AlertDialog(onDismissRequest = { newProfile = false }, title = { Text("Guardar mods activados como perfil") },
        text = { OutlinedTextField(value = profName, onValueChange = { profName = it.take(32) }, singleLine = true, label = { Text("Nombre") }) },
        confirmButton = { TextButton(onClick = { vm.saveProfile(profName); profName = ""; newProfile = false }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = { newProfile = false }) { Text("Cancelar") } })
}

// ---------------------------------------------------------------- ARCHIVOS
@Composable
private fun FilesScreen(vm: AppViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { vm.importUri(it) } }
    val p = vm.pending
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Importar paquetes .bl", style = MaterialTheme.typography.titleLarge)
        Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !vm.busy, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text(if (vm.busy) "Procesando…" else "Elegir archivo .bl")
        }
        if (p == null) {
            Text("El paquete se valida antes de instalar: ZIP, rutas, tamaños, CRC y manifiesto. Los mods se instalan desactivados.",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else if (p.report == null) {
            Section("Paquete rechazado") {
                Text(p.displayName, fontWeight = FontWeight.SemiBold)
                Text(p.error ?: "Error desconocido", color = MaterialTheme.colorScheme.error)
                TextButton(onClick = { vm.discardPending() }) { Text("Descartar") }
            }
        } else {
            val r = p.report; val m = r.manifest
            Section("Paquete válido") {
                Text("${m.name} · v${m.version}", fontWeight = FontWeight.SemiBold)
                Text("${r.kind.label} · id ${m.id}")
                Text("${r.entryCount} entradas · ${r.totalBytes / 1024} KB descomprimido" +
                    if (r.kind == BlKind.V2_JS) " · ${r.jsFiles} archivos JS" else "")
                Text("sha256 ${r.sha256.take(16)}…", style = MaterialTheme.typography.bodySmall)
                r.warnings.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                when (p.dup) {
                    DuplicateKind.SAME_FILE -> Text("Duplicado: este archivo ya está instalado.", color = MaterialTheme.colorScheme.error)
                    DuplicateKind.SAME_VERSION -> Text("Ya instalado la misma versión: se reemplazaría (con copia de seguridad).", color = MaterialTheme.colorScheme.error)
                    DuplicateKind.OTHER_VERSION -> Text("Otra versión instalada (${p.dupMod?.version}): se actualizaría (con copia de seguridad).")
                    DuplicateKind.NONE -> {}
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (p.dup != DuplicateKind.SAME_FILE) {
                        Button(onClick = { vm.confirmInstall(p.dup != DuplicateKind.NONE) }, enabled = !vm.busy) {
                            Text(if (p.dup == DuplicateKind.NONE) "Instalar" else "Reemplazar")
                        }
                    }
                    OutlinedButton(onClick = { vm.discardPending() }) { Text("Descartar") }
                }
            }
        }
    }
}

// ----------------------------------------------------------------- AJUSTES
@Composable
private fun SettingsScreen(vm: AppViewModel) {
    var logText by remember { mutableStateOf<String?>(null) }
    var mem by remember { mutableStateOf(vm.memoryLine()) }
    val t = remember { vm.terrariaInfo() }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ajustes", style = MaterialTheme.typography.titleLarge)
        Section("Bajo consumo") {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text("Límites de importación más estrictos (128 MB por paquete descomprimido, 100 MB de archivo)", Modifier.weight(1f))
                Switch(checked = vm.lowPower, onCheckedChange = { vm.setLowPower(it) })
            }
        }
        Section("Memoria y caché") {
            Text(mem, style = MaterialTheme.typography.bodySmall)
            Text("Caché de importación: ${vm.cacheBytes() / 1024} KB (límite ${vm.cacheLimitMb} MB)")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(16, 64, 128).forEach { mb ->
                    FilterChip(selected = vm.cacheLimitMb == mb, onClick = { vm.setCacheLimit(mb) }, label = { Text("$mb MB") })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.clearCache(); mem = vm.memoryLine() }) { Text("Vaciar caché") }
                OutlinedButton(onClick = { vm.clearBackups() }) { Text("Borrar copias (${vm.store.backupsSize() / 1024} KB)") }
            }
        }
        Section("Registros") {
            Text("Rotativos: 3 archivos de 128 KB como máximo (${vm.log.sizeBytes() / 1024} KB ahora)")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { logText = vm.log.tail() }) { Text("Ver") }
                OutlinedButton(onClick = { vm.clearLog() }) { Text("Vaciar") }
            }
        }
        Section("Dispositivo") {
            Text("${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            Text("ABIs: ${Build.SUPPORTED_ABIS.joinToString()}", style = MaterialTheme.typography.bodySmall)
            Text("ABIs 32 bits: ${Build.SUPPORTED_32_BIT_ABIS.joinToString().ifEmpty { "ninguna" }}", style = MaterialTheme.typography.bodySmall)
            Text("TerraBL nativo: ${NativeCore.abi()} · ${NativeCore.pointerBits()} bits", style = MaterialTheme.typography.bodySmall)
        }
        Section("Juego") {
            Text(if (t.installed) "Terraria ${t.versionName} · ABI ${t.abi}" else "Terraria no detectado")
        }
        Section("Acerca de") {
            Text("TerraBL Loader 0.1.0. Proyecto no oficial, basado en Bunny Loader (PolyForm Noncommercial 1.0.0). Uso no comercial.",
                style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(8.dp))
    }
    logText?.let { txt ->
        AlertDialog(onDismissRequest = { logText = null }, confirmButton = { TextButton(onClick = { logText = null }) { Text("Cerrar") } },
            title = { Text("Registro") }, text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(txt.ifEmpty { "(vacío)" }, style = MaterialTheme.typography.bodySmall) } })
    }
}
