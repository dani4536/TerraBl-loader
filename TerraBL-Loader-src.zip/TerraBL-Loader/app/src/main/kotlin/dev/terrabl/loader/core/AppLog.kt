package dev.terrabl.loader.core

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Registro rotativo: terrabl.log (actual) + .1 .. .(keep-1). Tamano total acotado. */
class AppLog(private val dir: File, private val maxBytes: Long = 128 * 1024, private val keep: Int = 3) {
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private val current get() = File(dir, "terrabl.log")

    @Synchronized
    fun write(level: String, msg: String) {
        try {
            dir.mkdirs()
            if (current.length() >= maxBytes) rotate()
            current.appendText("${fmt.format(Date())} [$level] $msg\n")
        } catch (e: Exception) { /* el registro nunca debe tumbar la app */ }
    }

    fun i(msg: String) = write("I", msg)
    fun w(msg: String) = write("W", msg)
    fun e(msg: String) = write("E", msg)

    private fun rotate() {
        File(dir, "terrabl.log.${keep - 1}").delete()
        for (n in keep - 2 downTo 1) File(dir, "terrabl.log.$n").renameTo(File(dir, "terrabl.log.${n + 1}"))
        current.renameTo(File(dir, "terrabl.log.1"))
    }

    /** Ultimos `maxChars` caracteres del registro actual. */
    @Synchronized
    fun tail(maxChars: Int = 6000): String {
        val t = if (current.exists()) current.readText() else ""
        return if (t.length > maxChars) t.takeLast(maxChars) else t
    }

    @Synchronized
    fun clear() {
        dir.listFiles()?.filter { it.name.startsWith("terrabl.log") }?.forEach { it.delete() }
    }

    fun sizeBytes(): Long = dir.listFiles()?.filter { it.name.startsWith("terrabl.log") }?.sumOf { it.length() } ?: 0L
}
