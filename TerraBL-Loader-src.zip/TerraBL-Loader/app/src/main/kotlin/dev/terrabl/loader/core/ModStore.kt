package dev.terrabl.loader.core

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

data class InstalledMod(
    val key: String,
    val dir: String,
    val id: String,
    val uid: String,
    val name: String,
    val version: String,
    val kind: BlKind,
    val enabled: Boolean,
    val installedAt: Long,
    val sha256: String,
    val sizeBytes: Long,
    val summary: String,
    val authors: List<String>,
)

enum class DuplicateKind { NONE, SAME_FILE, SAME_VERSION, OTHER_VERSION }

/**
 * Almacen de mods en disco:
 *   root/mods/<dir>/        contenido extraido (solo lectura para el resto de la app)
 *   root/state/mods.json    estado (activado, hash...)  -> escritura atomica
 *   root/state/profiles.json
 *   root/backups/           copias zip antes de reemplazar o eliminar (max 2 por mod)
 *   root/staging|trash/     temporales de instalacion/eliminacion
 * Todo es sincrono y bloqueante: llamar desde un hilo de fondo.
 */
class ModStore(private val root: File, private val log: AppLog? = null) {
    private val modsDir = File(root, "mods")
    private val stateFile = File(root, "state/mods.json")
    private val profilesFile = File(root, "state/profiles.json")
    private val backupsDir = File(root, "backups")
    private val stagingDir = File(root, "staging")
    private val trashDir = File(root, "trash")

    init {
        listOf(modsDir, stateFile.parentFile!!, backupsDir).forEach { it.mkdirs() }
        // Restos de una instalacion interrumpida (corte, matar el proceso).
        stagingDir.deleteRecursively(); trashDir.deleteRecursively()
    }

    // ---- consulta ----

    @Synchronized
    fun list(): List<InstalledMod> {
        val all = readState()
        val alive = all.filter { File(modsDir, it.dir).isDirectory }
        if (alive.size != all.size) writeState(alive) // reconciliar con el disco
        return alive.sortedBy { it.name.lowercase() }
    }

    @Synchronized
    fun findDuplicate(r: PackageReport): Pair<DuplicateKind, InstalledMod?> {
        val all = readState()
        all.firstOrNull { it.sha256 == r.sha256 }?.let { return DuplicateKind.SAME_FILE to it }
        val same = all.firstOrNull { it.key == r.manifest.key } ?: return DuplicateKind.NONE to null
        return (if (same.version == r.manifest.version) DuplicateKind.SAME_VERSION else DuplicateKind.OTHER_VERSION) to same
    }

    // ---- instalacion ----

    /** Instala un paquete ya inspeccionado. Atomico: o queda instalado entero o no cambia nada. */
    @Synchronized
    fun install(file: File, report: PackageReport, replace: Boolean = false): InstalledMod {
        val (dupKind, existing) = findDuplicate(report)
        if (dupKind == DuplicateKind.SAME_FILE) {
            throw PackageException("duplicate", "Este mismo archivo ya esta instalado (${existing!!.name} ${existing.version}).")
        }
        if (dupKind != DuplicateKind.NONE && !replace) {
            throw PackageException("duplicate", "${existing!!.name} ya esta instalado (v${existing.version}); confirma el reemplazo.")
        }
        val m = report.manifest
        val dirName = existing?.dir ?: uniqueDirName(m)
        val staging = File(stagingDir, UUID.randomUUID().toString())
        try {
            extractSafely(file, staging)
            if (existing != null) backup(existing, "replace")
            val target = File(modsDir, dirName)
            val trash = File(trashDir, "$dirName-${System.nanoTime()}")
            if (target.exists()) {
                trashDir.mkdirs()
                if (!target.renameTo(trash)) throw PackageException("io", "no se pudo apartar la version anterior")
            }
            if (!staging.renameTo(target)) {
                if (trash.exists()) trash.renameTo(target) // deshacer
                throw PackageException("io", "no se pudo mover la instalacion a su lugar")
            }
            trash.deleteRecursively()
        } catch (e: OutOfMemoryError) {
            staging.deleteRecursively()
            log?.e("OOM instalando ${m.id}")
            throw PackageException("oom", "Sin memoria al instalar; cierra otras apps o activa el modo de bajo consumo.")
        } catch (e: Exception) {
            staging.deleteRecursively()
            if (e is PackageException) throw e
            throw PackageException("io", "Error al instalar: ${e.message}")
        }
        val mod = InstalledMod(
            key = m.key, dir = dirName, id = m.id, uid = m.uid, name = m.name, version = m.version,
            kind = report.kind, enabled = existing?.enabled ?: false, // los mods nunca se activan solos
            installedAt = System.currentTimeMillis(), sha256 = report.sha256, sizeBytes = report.totalBytes,
            summary = m.summary, authors = m.authors,
        )
        writeState(readState().filter { it.key != m.key } + mod)
        log?.i("Instalado ${m.id} ${m.version} (${report.kind}) en $dirName")
        return mod
    }

    private fun uniqueDirName(m: BlManifest): String {
        val taken = readState().map { it.dir }.toSet()
        val base = m.id
        return if (base !in taken && !File(modsDir, base).exists()) base else "$base-${m.key.take(8)}"
    }

    /** Extrae con control de rutas y de bytes realmente escritos (no se fia de size declarado). */
    internal fun extractSafely(file: File, dest: File, limits: PackageLimits = PackageLimits()) {
        dest.mkdirs()
        val destCanon = dest.canonicalPath + File.separator
        var total = 0L
        ZipFile(file).use { z ->
            val en = z.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                val name = PackagePaths.safeEntryName(e.name)
                val out = File(dest, name)
                if (!out.canonicalPath.startsWith(destCanon)) throw PackageException("zip-slip", "ruta fuera del destino: $name")
                if (e.isDirectory) { out.mkdirs(); continue }
                out.parentFile!!.mkdirs()
                var n = 0L
                z.getInputStream(e).use { ins ->
                    out.outputStream().use { os ->
                        val buf = ByteArray(16 * 1024)
                        while (true) {
                            val r = ins.read(buf)
                            if (r < 0) break
                            n += r; total += r
                            if (n > limits.maxEntryBytes || total > limits.maxTotalBytes) {
                                throw PackageException("zip-big", "el paquete excede los limites al extraer")
                            }
                            os.write(buf, 0, r)
                        }
                    }
                }
            }
        }
    }

    // ---- activar / eliminar ----

    @Synchronized
    fun setEnabled(key: String, enabled: Boolean) {
        val all = readState()
        if (all.none { it.key == key }) throw PackageException("not-found", "mod no instalado")
        writeState(all.map { if (it.key == key) it.copy(enabled = enabled) else it })
        log?.i("${if (enabled) "Activado" else "Desactivado"} $key")
    }

    /** Elimina un mod. Antes guarda una copia de seguridad (recuperable en backups/). */
    @Synchronized
    fun remove(key: String, keepBackup: Boolean = true) {
        val mod = readState().firstOrNull { it.key == key } ?: throw PackageException("not-found", "mod no instalado")
        if (keepBackup) backup(mod, "remove")
        val target = File(modsDir, mod.dir)
        val trash = File(trashDir, "${mod.dir}-${System.nanoTime()}")
        trashDir.mkdirs()
        if (target.exists() && !target.renameTo(trash)) throw PackageException("io", "no se pudo eliminar ${mod.dir}")
        writeState(readState().filter { it.key != key })
        trash.deleteRecursively()
        val pr = profiles()
        if (pr.profiles.values.any { key in it }) {
            writeProfiles(pr.copy(profiles = pr.profiles.mapValues { it.value - key }))
        }
        log?.i("Eliminado ${mod.id} ${mod.version}")
    }

    private fun backup(mod: InstalledMod, why: String) {
        val src = File(modsDir, mod.dir)
        if (!src.isDirectory) return
        backupsDir.mkdirs()
        val out = File(backupsDir, "${mod.dir}-${mod.version}-$why-${System.currentTimeMillis()}.zip")
        ZipOutputStream(out.outputStream().buffered()).use { zos ->
            src.walkTopDown().filter { it.isFile }.forEach { f ->
                zos.putNextEntry(ZipEntry(f.relativeTo(src).path.replace(File.separatorChar, '/')))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
        // maximo 2 copias por mod
        backupsDir.listFiles { f -> f.name.startsWith("${mod.dir}-") }
            ?.sortedByDescending { it.lastModified() }?.drop(2)?.forEach { it.delete() }
    }

    fun backupsSize(): Long = backupsDir.listFiles()?.sumOf { it.length() } ?: 0L
    fun clearBackups() { backupsDir.listFiles()?.forEach { it.delete() } }

    /** Ruta del contenido extraido (para el motor, cuando exista). */
    fun dirOf(mod: InstalledMod): File = File(modsDir, mod.dir)

    // ---- perfiles ----

    data class Profiles(val active: String, val profiles: Map<String, Set<String>>)

    @Synchronized
    fun profiles(): Profiles {
        if (!profilesFile.exists()) return Profiles("", emptyMap())
        return try {
            val o = JSONObject(profilesFile.readText())
            val p = o.optJSONObject("profiles") ?: JSONObject()
            Profiles(o.optString("active", ""), p.keys().asSequence().associateWith { k ->
                val a = p.getJSONArray(k); (0 until a.length()).map { a.getString(it) }.toSet()
            })
        } catch (e: Exception) { log?.w("profiles.json ilegible: ${e.message}"); Profiles("", emptyMap()) }
    }

    @Synchronized
    fun saveProfile(name: String) {
        val n = name.trim()
        if (n.isEmpty() || n.length > 32) throw PackageException("profile-name", "nombre de perfil invalido (1-32 caracteres)")
        val keys = list().filter { it.enabled }.map { it.key }.toSet()
        val p = profiles()
        writeProfiles(Profiles(n, p.profiles + (n to keys)))
    }

    @Synchronized
    fun applyProfile(name: String) {
        val p = profiles()
        val keys = p.profiles[name] ?: throw PackageException("not-found", "perfil inexistente")
        writeState(readState().map { it.copy(enabled = it.key in keys) })
        writeProfiles(p.copy(active = name))
        log?.i("Perfil aplicado: $name")
    }

    @Synchronized
    fun deleteProfile(name: String) {
        val p = profiles()
        writeProfiles(Profiles(if (p.active == name) "" else p.active, p.profiles - name))
    }

    private fun writeProfiles(p: Profiles) {
        val o = JSONObject().put("active", p.active)
        val po = JSONObject()
        p.profiles.forEach { (k, v) -> po.put(k, JSONArray(v.toList())) }
        atomicWrite(profilesFile, o.put("profiles", po).toString())
    }

    // ---- persistencia ----

    private fun readState(): List<InstalledMod> {
        if (!stateFile.exists()) return emptyList()
        return try {
            val a = JSONArray(stateFile.readText())
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                InstalledMod(
                    key = o.getString("key"), dir = o.getString("dir"), id = o.getString("id"),
                    uid = o.optString("uid", ""), name = o.getString("name"), version = o.getString("version"),
                    kind = BlKind.valueOf(o.getString("kind")), enabled = o.optBoolean("enabled", false),
                    installedAt = o.optLong("installedAt"), sha256 = o.optString("sha256", ""),
                    sizeBytes = o.optLong("sizeBytes"), summary = o.optString("summary", ""),
                    authors = o.optJSONArray("authors")?.let { x -> (0 until x.length()).map { x.getString(it) } } ?: emptyList(),
                )
            }
        } catch (e: Exception) {
            // Estado corrupto: se conserva copia y se arranca vacio (no se borran los mods del disco).
            log?.e("mods.json corrupto (${e.message}); copia en mods.json.bad")
            stateFile.copyTo(File(stateFile.parentFile, "mods.json.bad"), overwrite = true)
            emptyList()
        }
    }

    private fun writeState(mods: List<InstalledMod>) {
        val a = JSONArray()
        mods.forEach {
            a.put(JSONObject().put("key", it.key).put("dir", it.dir).put("id", it.id).put("uid", it.uid)
                .put("name", it.name).put("version", it.version).put("kind", it.kind.name)
                .put("enabled", it.enabled).put("installedAt", it.installedAt).put("sha256", it.sha256)
                .put("sizeBytes", it.sizeBytes).put("summary", it.summary).put("authors", JSONArray(it.authors)))
        }
        atomicWrite(stateFile, a.toString())
    }

    private fun atomicWrite(f: File, text: String) {
        f.parentFile?.mkdirs()
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(f)) { f.delete(); if (!tmp.renameTo(f)) throw PackageException("io", "no se pudo guardar ${f.name}") }
    }
}
