package dev.terrabl.loader

/** Puente JNI al nucleo ARM32. Si la libreria no carga, el gestor sigue funcionando. */
object NativeCore {
    const val ERR_OK = 0
    const val ERR_NOT_IMPLEMENTED = 1

    val loaded: Boolean = try {
        System.loadLibrary("terrabl")
        true
    } catch (e: UnsatisfiedLinkError) {
        false
    }

    private external fun nativeAbi(): String
    private external fun nativePointerBits(): Int
    private external fun nativeStartJsEngine(): Int
    private external fun nativeStartCsharpRuntime(): Int

    fun abi(): String = if (loaded) nativeAbi() else "no cargada"
    fun pointerBits(): Int = if (loaded) nativePointerBits() else 0
    fun startJsEngine(): Int = if (loaded) nativeStartJsEngine() else ERR_NOT_IMPLEMENTED
    fun startCsharpRuntime(): Int = if (loaded) nativeStartCsharpRuntime() else ERR_NOT_IMPLEMENTED
}
