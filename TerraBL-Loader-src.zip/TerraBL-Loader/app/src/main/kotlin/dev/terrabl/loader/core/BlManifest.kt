package dev.terrabl.loader.core

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** Formato del paquete segun `blVersion` del manifiesto. No se inventa compatibilidad. */
enum class BlKind(val label: String) {
    V2_JS("BL v2 (JavaScript)"),
    V3_CSHARP("BL v3 (C#)"),
}

class PackageException(val code: String, message: String) : Exception(message)

data class BlManifest(
    val uid: String,
    val id: String,
    val name: String,
    val version: String,
    val blVersion: Int,
    val entry: String,
    val authors: List<String>,
    val category: String,
    val summary: String,
    val description: String,
    val icon: String,
    val license: String,
    val gameVersion: List<Long>,
    val dependencies: List<String>,
) {
    /** Identidad estable: uid si existe; si no, id. */
    val key: String get() = if (uid.isNotEmpty()) uid else id

    companion object {
        private val ID_RE = Regex("^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")
        private val UID_RE = Regex("^[0-9a-f-]{8,64}$")
        const val MAX_MANIFEST_BYTES = 256 * 1024

        fun parse(text: String): BlManifest {
            val o = try {
                JSONObject(text.removePrefix("\uFEFF"))
            } catch (e: JSONException) {
                throw PackageException("manifest-json", "manifest.json no es JSON valido: ${e.message}")
            }
            fun req(k: String): String {
                val v = o.optString(k, "").trim()
                if (v.isEmpty()) throw PackageException("manifest-missing", "manifest.json: falta el campo obligatorio \"$k\"")
                return v
            }
            val id = req("id")
            if (!ID_RE.matches(id)) {
                throw PackageException("manifest-id", "manifest.json: \"id\" invalido (solo letras, numeros, . _ -; max 64): $id")
            }
            val blVersion = o.optInt("blVersion", 1)
            if (blVersion != 2 && blVersion != 3) {
                throw PackageException(
                    "manifest-blversion",
                    "blVersion $blVersion no soportado (TerraBL entiende 2 y 3; sin campo = 1)"
                )
            }
            val uid = o.optString("uid", "").trim().lowercase()
            if (uid.isNotEmpty() && !UID_RE.matches(uid)) {
                throw PackageException("manifest-uid", "manifest.json: \"uid\" no tiene formato UUID: $uid")
            }
            return BlManifest(
                uid = uid,
                id = id,
                name = req("name"),
                version = req("version"),
                blVersion = blVersion,
                entry = o.optString("entry", ""),
                authors = parseAuthors(o.optJSONArray("authors"), o.optString("author", "")),
                category = o.optString("category", "Mod"),
                summary = o.optString("summary", ""),
                description = o.optString("description", ""),
                icon = o.optString("icon", ""),
                license = o.optString("license", ""),
                gameVersion = parseLongs(o.optJSONArray("gameVersion")),
                dependencies = parseDeps(o.optJSONArray("dependencies")),
            )
        }

        private fun parseAuthors(a: JSONArray?, single: String): List<String> {
            val out = ArrayList<String>()
            if (single.isNotBlank()) out += single
            if (a != null) for (i in 0 until a.length()) {
                when (val e = a.opt(i)) {
                    is String -> out += e
                    is JSONObject -> e.optString("name", "").takeIf { it.isNotBlank() }?.let { out += it }
                }
            }
            return out
        }

        private fun parseLongs(a: JSONArray?): List<Long> =
            if (a == null) emptyList() else (0 until a.length()).map { a.optLong(it) }

        private fun parseDeps(a: JSONArray?): List<String> {
            if (a == null) return emptyList()
            return (0 until a.length()).mapNotNull { i ->
                when (val e = a.opt(i)) {
                    is String -> e
                    is JSONObject -> e.optString("id", "").takeIf { it.isNotBlank() }
                    else -> null
                }
            }
        }
    }
}
