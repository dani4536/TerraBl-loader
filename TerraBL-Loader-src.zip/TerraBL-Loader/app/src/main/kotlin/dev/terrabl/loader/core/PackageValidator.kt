package dev.terrabl.loader.core

import java.io.File
import java.io.InputStream
import java.security.MessageDigest
import java.util.zip.CRC32
import java.util.zip.ZipException
import java.util.zip.ZipFile

/** Limites pensados para 2 GB de RAM: nada se carga entero en memoria salvo manifiesto y JS < 2 MB. */
data class PackageLimits(
    val maxEntries: Int = 4000,
    val maxEntryBytes: Long = 64L * 1024 * 1024,
    val maxTotalBytes: Long = 256L * 1024 * 1024,
    val maxCompressionRatio: Long = 200,
)

data class PackageReport(
    val manifest: BlManifest,
    val kind: BlKind,
    val entryCount: Int,
    val totalBytes: Long,
    val fileSize: Long,
    val sha256: String,
    val warnings: List<String>,
    val jsFiles: Int,
    val hasEntryFile: Boolean,
)

object PackageValidator {

    private val IMPORT_RE = Regex("""(?:import|export)\s[^;]*?from\s*['"]([^'"]+)['"]""")

    /**
     * Valida un .bl sin extraerlo: estructura ZIP, rutas, limites, CRC, manifiesto y la
     * disposicion propia de cada formato. Lanza PackageException con un mensaje legible.
     */
    fun inspect(file: File, limits: PackageLimits = PackageLimits()): PackageReport {
        val magic = ByteArray(4)
        val got = file.inputStream().use { it.read(magic) }
        if (got < 4 || magic[0] != 0x50.toByte() || magic[1] != 0x4B.toByte()) {
            val hex = magic.take(maxOf(got, 0)).joinToString(" ") { "%02x".format(it) }
            throw PackageException("not-zip", "${file.name}: no es un ZIP (primeros bytes: $hex; un .bl empieza por 50 4b)")
        }
        val zip = try {
            ZipFile(file)
        } catch (e: ZipException) {
            throw PackageException("zip-corrupt", "${file.name}: ZIP danado (${e.message})")
        }
        return zip.use { z ->
            val names = LinkedHashSet<String>()
            var total = 0L
            var count = 0
            val entries = z.entries()
            while (entries.hasMoreElements()) {
                val e = entries.nextElement()
                count++
                if (count > limits.maxEntries) throw PackageException("zip-entries", "demasiadas entradas (> ${limits.maxEntries})")
                val name = PackagePaths.safeEntryName(e.name)
                if (!names.add(name.lowercase())) throw PackageException("zip-duplicate", "entrada duplicada en el ZIP: $name")
                if (e.isDirectory) continue
                val size = e.size
                if (size < 0) throw PackageException("zip-size", "tamano desconocido para $name")
                if (size > limits.maxEntryBytes) throw PackageException("zip-big", "$name supera ${limits.maxEntryBytes / 1048576} MB")
                if (e.compressedSize > 0 && size > 1_000_000 && size / e.compressedSize > limits.maxCompressionRatio) {
                    throw PackageException("zip-bomb", "$name tiene una compresion sospechosa (posible zip bomb)")
                }
                total += size
                if (total > limits.maxTotalBytes) throw PackageException("zip-total", "el paquete descomprimido supera ${limits.maxTotalBytes / 1048576} MB")
            }

            val mEntry = z.getEntry("manifest.json")
                ?: throw PackageException("no-manifest", "no hay manifest.json en la raiz del paquete")
            if (mEntry.size > BlManifest.MAX_MANIFEST_BYTES) throw PackageException("manifest-big", "manifest.json demasiado grande")
            val manifest = BlManifest.parse(z.getInputStream(mEntry).use { String(it.readBytes(), Charsets.UTF_8) })

            // Integridad: CRC de cada archivo, en streaming (sin cargarlo en memoria).
            val buf = ByteArray(16 * 1024)
            val en2 = z.entries()
            while (en2.hasMoreElements()) {
                val e = en2.nextElement()
                if (e.isDirectory) continue
                val crc = CRC32()
                var n = 0L
                try {
                    z.getInputStream(e).use { ins ->
                        while (true) {
                            val r = ins.read(buf)
                            if (r < 0) break
                            crc.update(buf, 0, r); n += r
                            if (n > limits.maxEntryBytes) throw PackageException("zip-big", "${e.name} excede el limite al descomprimir")
                        }
                    }
                } catch (ex: PackageException) {
                    throw ex
                } catch (ex: Exception) {
                    throw PackageException("zip-corrupt", "${e.name}: no se puede leer (${ex.message})")
                }
                if (e.crc != -1L && e.crc != crc.value) throw PackageException("zip-crc", "${e.name}: CRC incorrecto (archivo corrupto)")
            }

            val warnings = ArrayList<String>()
            val kind: BlKind
            var jsFiles = 0
            val hasEntry: Boolean
            if (manifest.blVersion == 2) {
                kind = BlKind.V2_JS
                val entryName = manifest.entry.ifEmpty { "main.js" }
                PackagePaths.safeEntryName(entryName)
                hasEntry = z.getEntry("content/$entryName") != null
                if (!hasEntry) throw PackageException("v2-entry", "BL v2: falta content/$entryName")
                jsFiles = names.count { it.startsWith("content/") && it.endsWith(".js") }
                checkV2Imports(z, names, warnings)
                warnings += "BL v2: el paquete se instala y se lee; los hooks de Terraria NO funcionan hasta tener la integracion nativa."
            } else {
                kind = BlKind.V3_CSHARP
                val cs = "${manifest.id}.cs".lowercase()
                val dll = "${manifest.id}.dll".lowercase()
                hasEntry = names.contains(cs) || names.contains(dll)
                if (!hasEntry) throw PackageException("v3-entry", "BL v3: falta ${manifest.id}.cs o ${manifest.id}.dll en la raiz")
                warnings += "BL v3 (C#): se puede importar y listar, pero NO ejecutar: el runtime C# ARM32 aun no existe."
            }
            if (manifest.icon.isNotEmpty() && z.getEntry(manifest.icon) == null) {
                val alt = listOf("icon.png", "icon.gif").firstOrNull { z.getEntry(it) != null }
                warnings += if (alt != null) "El icono declarado (${manifest.icon}) no esta; se usara $alt."
                else "El icono declarado (${manifest.icon}) no esta en el paquete."
            }
            if (manifest.uid.isEmpty()) warnings += "El manifiesto no tiene uid; se identificara por id."
            if (manifest.dependencies.isNotEmpty()) warnings += "El mod declara dependencias: ${manifest.dependencies.joinToString()}."

            PackageReport(
                manifest = manifest, kind = kind, entryCount = count, totalBytes = total,
                fileSize = file.length(), sha256 = sha256(file), warnings = warnings,
                jsFiles = jsFiles, hasEntryFile = hasEntry,
            )
        }
    }

    /** Comprueba que cada import relativo de los .js apunta a un archivo del paquete. */
    private fun checkV2Imports(z: ZipFile, names: Set<String>, warnings: MutableList<String>) {
        var unresolved = 0
        val en = z.entries()
        while (en.hasMoreElements()) {
            val e = en.nextElement()
            if (e.isDirectory || !e.name.endsWith(".js") || !e.name.startsWith("content/")) continue
            if (e.size > 2L * 1024 * 1024) continue // JS gigante: no se analiza (limite de memoria)
            val text = z.getInputStream(e).use { String(it.readBytes(), Charsets.UTF_8) }
            for (m in IMPORT_RE.findAll(text)) {
                val spec = m.groupValues[1]
                if (!spec.startsWith(".")) continue
                val target = resolveRelative(e.name, spec)
                if (target == null || !names.contains(target.lowercase())) {
                    unresolved++
                    if (unresolved <= 5) warnings += "Import sin resolver en ${e.name}: $spec"
                }
            }
        }
        if (unresolved > 5) warnings += "... y ${unresolved - 5} imports sin resolver mas."
    }

    /** Resuelve `./x.js` / `../y.js` contra el directorio del importador; null si se sale del paquete. */
    fun resolveRelative(importer: String, spec: String): String? {
        val stack = ArrayList(importer.split('/').dropLast(1))
        for (part in spec.split('/')) {
            when (part) {
                "", "." -> {}
                ".." -> if (stack.isEmpty()) return null else stack.removeAt(stack.size - 1)
                else -> stack += part
            }
        }
        return stack.joinToString("/")
    }

    fun sha256(file: File): String = file.inputStream().use { sha256(it) }

    fun sha256(ins: InputStream): String {
        val md = MessageDigest.getInstance("SHA-256")
        val b = ByteArray(32 * 1024)
        while (true) { val r = ins.read(b); if (r < 0) break; md.update(b, 0, r) }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
