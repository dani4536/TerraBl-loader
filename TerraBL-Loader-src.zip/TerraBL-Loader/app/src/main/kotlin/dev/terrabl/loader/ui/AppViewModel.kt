package dev.terrabl.loader.ui

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.terrabl.loader.core.AppLog
import dev.terrabl.loader.core.DuplicateKind
import dev.terrabl.loader.core.InstalledMod
import dev.terrabl.loader.core.ModStore
import dev.terrabl.loader.core.PackageException
import dev.terrabl.loader.core.PackageLimits
import dev.terrabl.loader.core.PackageReport
import dev.terrabl.loader.core.PackageValidator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.io.InputStream
import java.io.OutputStream

/** Resultado de analizar un .bl: o un informe valido o un error legible. */
data class Pending(
    val displayName: String,
    val report: PackageReport?,
    val error: String?,
    val dup: DuplicateKind,
    val dupMod: InstalledMod?,
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    companion object {
        const val TERRARIA_PKG = "com.and.games505.TerrariaPaid" // id de Google Play citado en el README de Bunny Loader
    }

    private val ctx: Context = app.applicationContext
    val log = AppLog(File(ctx.filesDir, "logs"))
    val store = ModStore(File(ctx.filesDir, "terrabl"), log)
    private val prefs = ctx.getSharedPreferences("terrabl", Context.MODE_PRIVATE)
    private val importDir = File(ctx.cacheDir, "imports")
    private val pendingFile = File(importDir, "pending.bl")

    var mods by mutableStateOf<List<InstalledMod>>(emptyList()); private set
    var profiles by mutableStateOf(ModStore.Profiles("", emptyMap())); private set
    var pending by mutableStateOf<Pending?>(null); private set
    var message by mutableStateOf<String?>(null)
    var busy by mutableStateOf(false); private set
    var lowPower by mutableStateOf(prefs.getBoolean("lowPower", true)); private set
    var cacheLimitMb by mutableStateOf(prefs.getInt("cacheMb", 64)); private set

    init { refresh() }

    // ---- ajustes ----
    fun updateLowPower(v: Boolean) { lowPower = v; prefs.edit().putBoolean("lowPower", v).apply() }
    fun updateCacheLimit(mb: Int) { cacheLimitMb = mb; prefs.edit().putInt("cacheMb", mb).apply(); trimCache() }

    private fun limits() =
        if (lowPower) PackageLimits(maxEntries = 2000, maxEntryBytes = 32L shl 20, maxTotalBytes = 128L shl 20)
        else PackageLimits()

    private fun maxImportBytes() = if (lowPower) 100L shl 20 else 200L shl 20

    // ---- lista ----
    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            mods = store.list()
            profiles = store.profiles()
        }
    }

    private inline fun <T> guarded(what: String, block: () -> T): T? = try {
        block()
    } catch (e: PackageException) {
        log.w("$what: ${e.message}"); message = e.message; null
    } catch (e: OutOfMemoryError) {
        log.e("$what: sin memoria"); message = "Sin memoria. Cierra otras apps o activa el modo de bajo consumo."; null
    } catch (e: Exception) {
        log.e("$what: ${e.javaClass.simpleName} ${e.message}"); message = "Error inesperado: ${e.message}"; null
    }

    fun toggle(mod: InstalledMod, enabled: Boolean) = viewModelScope.launch(Dispatchers.IO) {
        guarded("activar") { store.setEnabled(mod.key, enabled) }
        refresh()
    }

    fun remove(mod: InstalledMod) = viewModelScope.launch(Dispatchers.IO) {
        guarded("eliminar") { store.remove(mod.key) }
        refresh()
    }

    fun saveProfile(name: String) = viewModelScope.launch(Dispatchers.IO) {
        guarded("perfil") { store.saveProfile(name) }; refresh()
    }

    fun applyProfile(name: String) = viewModelScope.launch(Dispatchers.IO) {
        guarded("perfil") { store.applyProfile(name) }; refresh()
    }

    fun deleteProfile(name: String) = viewModelScope.launch(Dispatchers.IO) {
        guarded("perfil") { store.deleteProfile(name) }; refresh()
    }

    // ---- importacion ----
    fun importUri(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        busy = true
        val name = displayName(uri)
        try {
            trimCache()
            importDir.mkdirs()
            pendingFile.delete()
            val ins = ctx.contentResolver.openInputStream(uri) ?: throw PackageException("io", "no se pudo abrir el archivo")
            ins.use { i -> pendingFile.outputStream().use { o -> copyLimited(i, o, maxImportBytes()) } }
            val report = PackageValidator.inspect(pendingFile, limits())
            val (dk, dm) = store.findDuplicate(report)
            pending = Pending(name, report, null, dk, dm)
            log.i("Analizado $name: ${report.manifest.id} ${report.manifest.version} ${report.kind}")
        } catch (e: PackageException) {
            pendingFile.delete(); log.w("Rechazado $name: ${e.message}")
            pending = Pending(name, null, e.message, DuplicateKind.NONE, null)
        } catch (e: OutOfMemoryError) {
            pendingFile.delete(); log.e("Sin memoria analizando $name")
            pending = Pending(name, null, "Sin memoria al analizar el paquete.", DuplicateKind.NONE, null)
        } catch (e: Exception) {
            pendingFile.delete(); log.e("Error importando $name: ${e.message}")
            pending = Pending(name, null, "No se pudo leer el archivo: ${e.message}", DuplicateKind.NONE, null)
        } finally { busy = false }
    }

    fun confirmInstall(replace: Boolean) {
        val p = pending ?: return
        val r = p.report ?: return
        viewModelScope.launch(Dispatchers.IO) {
            busy = true
            val ok = guarded("instalar") { store.install(pendingFile, r, replace) }
            if (ok != null) { message = "Instalado: ${ok.name} ${ok.version} (desactivado; actívalo en Mods)"; pending = null; pendingFile.delete() }
            busy = false
            refresh()
        }
    }

    fun discardPending() { pending = null; pendingFile.delete() }

    private fun displayName(uri: Uri): String = try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: uri.lastPathSegment ?: "paquete.bl"
    } catch (e: Exception) { "paquete.bl" }

    private fun copyLimited(i: InputStream, o: OutputStream, max: Long) {
        val b = ByteArray(32 * 1024); var n = 0L
        while (true) {
            val r = i.read(b); if (r < 0) break
            n += r
            if (n > max) throw PackageException("too-big", "El archivo supera ${max shr 20} MB.")
            o.write(b, 0, r)
        }
    }

    // ---- cache y memoria ----
    fun cacheBytes(): Long = importDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    fun trimCache() {
        val limit = cacheLimitMb.toLong() shl 20
        if (pending == null && cacheBytes() > limit) importDir.deleteRecursively()
    }

    fun clearCache() { if (pending == null) importDir.deleteRecursively(); message = "Cache vaciada" }
    fun clearLog() { log.clear(); message = "Registro vaciado" }
    fun clearBackups() { store.clearBackups(); message = "Copias de seguridad eliminadas" }

    fun memoryLine(): String {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        val rt = Runtime.getRuntime()
        return "RAM libre ${mi.availMem shr 20} MB de ${mi.totalMem shr 20} MB" +
            (if (mi.lowMemory) " (poca memoria)" else "") +
            " · heap app ${(rt.totalMemory() - rt.freeMemory()) shr 20} MB"
    }

    // ---- Terraria ----
    data class TerrariaInfo(val installed: Boolean, val versionName: String, val abi: String)

    fun terrariaInfo(): TerrariaInfo = try {
        @Suppress("DEPRECATION")
        val pi = ctx.packageManager.getPackageInfo(TERRARIA_PKG, 0)
        val abi = try {
            ApplicationInfo_primaryCpuAbi(pi.applicationInfo) ?: "desconocida"
        } catch (e: Throwable) { "desconocida" }
        TerrariaInfo(true, pi.versionName ?: "?", abi)
    } catch (e: PackageManager.NameNotFoundException) {
        TerrariaInfo(false, "", "")
    }

    /** `primaryCpuAbi` no es API publica: se lee por reflexion y puede fallar; se informa como "desconocida". */
    private fun ApplicationInfo_primaryCpuAbi(ai: android.content.pm.ApplicationInfo?): String? {
        if (ai == null) return null
        return ai.javaClass.getField("primaryCpuAbi").get(ai) as? String
    }
}
