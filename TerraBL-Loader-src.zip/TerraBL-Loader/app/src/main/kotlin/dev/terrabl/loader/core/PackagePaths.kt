package dev.terrabl.loader.core

/** Control de rutas de entradas ZIP (proteccion contra ZIP Slip y rutas peligrosas). */
object PackagePaths {
    /** Devuelve la ruta tal cual si es segura; lanza PackageException si no. */
    fun safeEntryName(raw: String): String {
        if (raw.isEmpty()) throw PackageException("zip-path", "entrada con nombre vacio")
        if (raw.indexOf('\u0000') >= 0) throw PackageException("zip-path", "entrada con byte nulo")
        if (raw.contains('\\')) throw PackageException("zip-path", "ruta con barra invertida no permitida: $raw")
        if (raw.startsWith("/")) throw PackageException("zip-path", "ruta absoluta no permitida: $raw")
        if (raw.length >= 2 && raw[1] == ':') throw PackageException("zip-path", "ruta con unidad no permitida: $raw")
        if (raw.length > 240) throw PackageException("zip-path", "ruta demasiado larga")
        for (p in raw.trimEnd('/').split('/')) {
            if (p == ".." || p == "." || p.isEmpty()) {
                throw PackageException("zip-slip", "ruta insegura (ZIP Slip): $raw")
            }
        }
        return raw
    }
}
