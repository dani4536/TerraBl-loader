# PROGRESS

Última actualización: sesión 2.

## Hecho (escrito, NO compilado, NO probado en dispositivo)
- Análisis de `Bunny-Loader-main.zip` y `arkofthecosmos.bl` → docs/COMPATIBILITY.md
- Gradle (AGP 8.5.2, Kotlin 1.9.24, Compose BOM 2024.06), ABI solo armeabi-v7a, CMake con guardia de ABI
- Núcleo nativo mínimo: `core/jni_core.cpp`, `error.*`, `NativeCore.kt` (ABI, bits, motores = NotImplemented)
- `core/BlManifest.kt`, `PackagePaths.kt`, `PackageValidator.kt` (ZIP Slip, límites, CRC, zip bomb, layout v2/v3, imports JS)
- `core/ModStore.kt` (instalación atómica, duplicados, activar, eliminar con backup, perfiles), `AppLog.kt` (logs rotativos)
- UI Compose: Inicio, Mods, Archivos, Ajustes (`ui/Screens.kt`, `ui/AppViewModel.kt`)
- Tests JVM: `PackageValidatorTest`, `ModStoreTest` (incluye el .bl real en `testdata/`)
- Workflow `.github/workflows/build.yml` (tests + APK + verificación ELF ARM32)

## Pruebas (registro honesto)
| # | Prueba | Resultado |
|---|---|---|
| 1 | Compilación | NO ejecutada (sin SDK/NDK/red en la sesión) |
| 2 | Generación de APK | NO ejecutada |
| 3 | Verificación ABI | NO ejecutada (el workflow la hace) |
| 4-6,9-11 | Instalar/abrir/importar/activar/errores/memoria | NO ejecutadas |
| 7 | Manifiesto BL v2 del mod real | Verificado con un script Python (imports, iconos, estructura); el test Kotlin equivalente NO se ha ejecutado |
| 8 | Detección BL v3 | Solo test escrito, sin ejecutar |
| 12 | Integración Terraria | No aplicable: sin binarios ARM32 |

## Sesión 2 (revisión de configuración)
- Corregido: `catch (_: X)` (no válido en Kotlin 1.9) → `catch (e: X)`; `if` sin `else` como última expresión de `let`; `return` dentro de `zip.use`; DSL de CMake (`cppFlags()/arguments()`); lint ya no bloquea el APK.
- Verificado en el host (no es compilar para ARM): sintaxis C++17 de `core/*.cpp` con stubs de JNI, XML bien formado, YAML del workflow válido, `tools/preflight.py` OK.
- Workflow nuevo: compila desde proyecto descomprimido **o** desde un `.zip` en la raíz (para subir desde el móvil), verifica ELF ARM32, publica artefacto + Release, tests informativos.
- Sigue SIN ejecutarse: compilación Gradle/Kotlin, generación de APK, instalación, cualquier prueba en dispositivo.

## Errores/riesgos conocidos
- Primer build de CI probablemente falle por errores no detectados (código sin compilar).
- Falta `gradle-wrapper.jar` (CI usa Gradle 8.7 instalado).
- Sin icono de launcher propio (usa el por defecto de Android).

## Cómo continuar
Leer ARCHITECTURE.md y TODO.md. Primer paso: subir a GitHub, ejecutar el workflow, corregir errores de compilación y registrar aquí el resultado real.
