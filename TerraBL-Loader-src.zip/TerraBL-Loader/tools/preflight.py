#!/usr/bin/env python3
"""Comprobaciones estaticas baratas ANTES de compilar. No sustituye a compilar.
Sale con codigo 1 si hay errores de configuracion (archivos que faltan, ABI incorrecta, XML roto)."""
import os, re, sys, xml.etree.ElementTree as ET

root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
errors, warns = [], []
def err(m): errors.append(m)
def read(p): return open(os.path.join(root, p), encoding="utf-8").read()

required = """settings.gradle.kts build.gradle.kts gradle.properties app/build.gradle.kts app/proguard-rules.pro
app/src/main/AndroidManifest.xml app/src/main/res/values/strings.xml app/src/main/res/values/themes.xml
app/src/main/cpp/CMakeLists.txt app/src/main/cpp/core/jni_core.cpp app/src/main/cpp/core/error.cpp app/src/main/cpp/core/error.h
app/src/main/kotlin/dev/terrabl/loader/MainActivity.kt app/src/main/kotlin/dev/terrabl/loader/NativeCore.kt
app/src/main/kotlin/dev/terrabl/loader/core/ModStore.kt app/src/main/kotlin/dev/terrabl/loader/ui/Screens.kt
testdata/arkofthecosmos.bl""".split()
for f in required:
    if not os.path.isfile(os.path.join(root, f)): err(f"falta el archivo: {f}")

g = read("app/build.gradle.kts") if os.path.isfile(os.path.join(root, "app/build.gradle.kts")) else ""
if 'abiFilters += "armeabi-v7a"' not in g: err('app/build.gradle.kts: falta abiFilters += "armeabi-v7a"')
if "arm64" in g or "x86" in g: err("app/build.gradle.kts menciona arm64/x86: el objetivo es SOLO armeabi-v7a")
cm = read("app/src/main/cpp/CMakeLists.txt")
if 'STREQUAL "armeabi-v7a"' not in cm: err("CMakeLists.txt: falta la guardia de ABI armeabi-v7a")

for x in ["app/src/main/AndroidManifest.xml", "app/src/main/res/values/strings.xml", "app/src/main/res/values/themes.xml"]:
    try: ET.parse(os.path.join(root, x))
    except Exception as e: err(f"XML mal formado {x}: {e}")

# JNI: cada 'external fun' de NativeCore debe tener su funcion C++ Java_dev_terrabl_loader_NativeCore_<nombre>
kt = read("app/src/main/kotlin/dev/terrabl/loader/NativeCore.kt"); cpp = read("app/src/main/cpp/core/jni_core.cpp")
for name in re.findall(r"external fun (\w+)\(", kt):
    if f"Java_dev_terrabl_loader_NativeCore_{name}" not in cpp: err(f"JNI: falta Java_dev_terrabl_loader_NativeCore_{name} en jni_core.cpp")

# Kotlin: equilibrio de llaves/parentesis (aviso, el texto puede contener caracteres sueltos)
for dp, _, fs in os.walk(os.path.join(root, "app/src")):
    for f in fs:
        if f.endswith(".kt"):
            t = open(os.path.join(dp, f), encoding="utf-8").read()
            for a, b in ("{}", "()", "[]"):
                if t.count(a) != t.count(b): warns.append(f"{f}: '{a}' x{t.count(a)} vs '{b}' x{t.count(b)}")

for line in g.splitlines():
    if re.search(r"ndkVersion|compileSdk|minSdk|targetSdk|kotlinCompilerExtensionVersion", line): print("  ", line.strip())
print("  ", [l.strip() for l in read("build.gradle.kts").splitlines() if "version" in l])

try:
    import yaml; yaml.safe_load(open(os.path.join(root, ".github/workflows/build.yml"))); print("   workflow YAML valido")
except ImportError: warns.append("PyYAML no disponible: workflow no comprobado")
except Exception as e: err(f"workflow YAML invalido: {e}")

for w in warns: print("AVISO:", w)
for e in errors: print("ERROR:", e)
print("preflight:", "FALLO" if errors else "OK (configuracion coherente; esto NO es una compilacion)")
sys.exit(1 if errors else 0)
