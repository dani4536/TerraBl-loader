# Informe de compatibilidad BL v2 / BL v3

Estado: **análisis estático y diseño**. Ninguna prueba en dispositivo ni en Terraria se ha ejecutado.

## 1. Bunny-Loader-main.zip (análisis)
| Aspecto | Hallazgo (archivo de origen) |
|---|---|
| ABI | Solo `arm64-v8a`: `app/build.gradle.kts` hace `abiFilters.clear(); += "arm64-v8a"` y comenta que el runtime existe solo para arm64 |
| SDK/NDK | minSdk 24, compileSdk 34, NDK 30.0.16248370, C++20 |
| Hooking nativo | ShadowHook 1.0.10 (prefab). Soporte ARM32 de la librería: **no verificado aquí** |
| Hooks propios | `hook/Arm64Frame.h`, `script/dotnet/HookGate.S`, `HookProfileThunks.S`, `il2cpp/GuardedCall.S`: ensamblador AArch64 → reescritura obligatoria para ARM32 |
| IL2CPP | `il2cpp/Api.cpp, Resolver.cpp, Signature.cpp`: resolución en runtime; offsets validados por `GameRefs` |
| Runtime C# | Mono (`libmonosgen-2.0.so`) del pack NuGet `...Mono.android-arm64` 10.0.14, BCL `net10.0`, compilador Roslyn en dispositivo |
| Unity | Aloja `UnityPlayer` en su proceso; requiere `unity-classes.jar` 2021.3.56f2 (no incluido) |
| PairIP | Terraria lo usa; el alojamiento falla; decisión de arquitectura "abierta" en su doc |
| Formato | `blVersion` 3 es el único que carga; v2 "no carga más". Catálogo: `BlPackage.BL_VERSION` |
| JS | Puente JS eliminado del código actual; solo documentación histórica |
| Licencia | PolyForm Noncommercial; marca protegida (ver ARCHITECTURE D7) |

**Consecuencia clave:** el Bunny Loader actual **no puede cargar el mod de prueba** (`blVersion: 2`). Cargarlo exige reconstruir el motor JS histórico además de la integración.

## 2. arkofthecosmos.bl (análisis verificado con script)
- ZIP válido, 121 entradas, 983 737 B descomprimido; SHA-256 del archivo `c9e33fad…a11b`.
- `manifest.json`: id `arkofthecosmos`, "Calamity Swords(js)", v1.12.7, `blVersion: 2`, `entry: main.js`, `dependencies: []`, `gameVersion: [301720, 301720]`, licencia MIT.
- Recursos: 55 PNG (texturas, 5 botones táctiles), 5 OGG, 2 JSON de localización (en-US, es-ES), `icon.gif`.
- 56 archivos JS, 55 imports ES relativos, **todos resuelven**; sin `import()` dinámico ni `require`. Formas de export: `export default class`, `export class`, `export function`.
- `main.js`: `export default class ArkOfTheCosmosMod extends Mod` con `Load()` y `PostSetupContent()`.
- API `bl.*` usada: solo `bl.log` y `bl.loadTexture`.
- Globals del puente a Terraria usados (por frecuencia): `Main.*` (screenPosition, player, myPlayer, npc, projectile, spriteBatch, MouseWorld, hardMode...), `SoundID`, `SoundEngine.PlaySound`, `ModConfig.Toggle/Header`, `ModItem/ModProjectile.getTypeByName`, `Player.Update`, `Item.sellPrice`, `TextureAssets`, `PlayerInput`.
- **Hooks:** `Load()` instala `InstallExoArmHook()` e `InstallSwordArmHook()` (modifican `Player.Update`/brazo del jugador). Requieren hook engine + puente a clases del juego.
- **Hallazgo:** el manifiesto declara `"icon": "icon.png"` pero el paquete trae `icon.gif`. No se modificó; TerraBL avisa y usa `icon.gif`.

## 3. Matriz de estado
| Función | Estado |
|---|---|
| Importar/validar/instalar `.bl` v2 y v3 | Implementado en código; **sin compilar ni probar** |
| Detectar v2 vs v3 | Implementado; test JVM escrito (sin ejecutar) |
| Leer manifiesto v2 del mod real | Test escrito contra el archivo real (sin ejecutar) |
| Ejecutar `main.js` (QuickJS ARM32) | **No implementado** |
| Hooks v2 en Terraria | **No implementado, no probado** |
| Runtime C# ARM32 (v3) | **No implementado** |
| Integración con Terraria ARM32 | **No implementada**; faltan datos (ver LIMITATIONS) |

Regla: no se marca como "funciona" nada que no tenga una prueba ejecutada y registrada en PROGRESS.md.
