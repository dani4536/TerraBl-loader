# Compilar, instalar e importar

## Compilar con GitHub Actions (recomendado)
Pasos desde el móvil: ver `README.md`. Resumen técnico:
1. Crea un repositorio en GitHub y sube el contenido de esta carpeta (raíz = donde está `settings.gradle.kts`).
2. Pestaña **Actions** → "Build TerraBL Loader (ARM32)" → **Run workflow** (también corre en cada push).
3. El job: instala NDK 26.1 + CMake 3.22.1, ejecuta tests JVM, genera APK debug y release, y **verifica** que todo `.so` es ELF ARM 32 bits en `lib/armeabi-v7a/`.
4. Descarga el artefacto `TerraBL-Loader-apk-armeabi-v7a`.
5. Si falla (probable en el primer intento: el código no se compiló antes), abre el log, corrige y vuelve a subir. Anota el error en PROGRESS.md.

## Compilar en local
Requisitos: JDK 17, Android SDK 34, NDK 26.1.10909125, CMake 3.22.1, Gradle 8.7 (el repo no incluye `gradle-wrapper.jar`; ejecuta `gradle wrapper --gradle-version 8.7` una vez).
```
gradle :app:testDebugUnitTest
gradle :app:assembleDebug :app:assembleRelease
```
APK en `app/build/outputs/apk/{debug,release}/`.

## Instalar en el Elite A63Max (Android 13, 32 bits)
- Copia el APK al teléfono, permite "instalar apps desconocidas" para tu gestor de archivos, abre el APK.
- Con ADB: `adb install -r app-debug.apk`.
- Comprueba la ABI del APK: `unzip -l app-debug.apk | grep lib/` solo debe mostrar `lib/armeabi-v7a/libterrabl.so`.

## Importar mods
Archivos → "Elegir archivo .bl" → revisa el informe (errores/avisos/duplicados) → Instalar. Luego Mods → interruptor para activar. Para probar: `testdata/arkofthecosmos.bl`.

## Release propio
Crea tu keystore y sustituye `signingConfig` de `release` en `app/build.gradle.kts`. No publiques con la clave de depuración.
