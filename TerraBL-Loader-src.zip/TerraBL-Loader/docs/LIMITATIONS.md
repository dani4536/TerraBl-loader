# Limitaciones reales

1. **No se ha compilado nada.** El sandbox de desarrollo no tenía Android SDK/NDK/Gradle ni red. El código Kotlin/C++ no ha pasado por un compilador: es probable que el primer build de CI revele errores de sintaxis o de dependencias. Hay que ejecutar el workflow y corregir.
2. **No hay APK todavía.** Se obtiene de GitHub Actions (docs/BUILD.md). Release firmado con la clave de depuración: solo para uso propio.
3. **No hay motor de mods.** Ni QuickJS, ni hook engine ARMv7, ni IL2CPP bridge, ni runtime C#. Los archivos nativos actuales solo informan ABI y devuelven "no implementado".
4. **Activar un mod no lo ejecuta.** Solo lo marca; la UI lo indica.
5. **Terraria ARM32 desconocido.** No sé si Terraria Mobile 1.4.5.8.6 incluye `armeabi-v7a`, ni si el MT6739 puede ejecutar la versión 64 bits (el A63Max con Android 13 de 32 bits solo instalará APKs con libs 32 bits). Se necesita comprobarlo (Inicio muestra la ABI del juego instalado).
6. **PairIP** (protección de Terraria en Google Play) impide alojar Unity fuera de su arranque legítimo; las rutas posibles requieren root o re-empaquetar la copia propia del usuario (ver ARCHITECTURE D6).
7. **Faltan para la integración (el usuario debe aportarlos legítimamente):** `libil2cpp.so` y `libunity.so` ARM32 de su Terraria; `global-metadata.dat`; versión exacta del juego; un volcado de offsets IL2CPP para esa versión; `unity-classes.jar` 2021.3.56f2 (ABI-independiente, de Unity).
8. **.NET 10/Mono ARM64 no sirve.** Hay que verificar un runtime Mono ARM32 y reescribir el ensamblador a ARM/Thumb-2.
9. Rendimiento en 2 GB no medido; los límites de memoria son diseño, no resultados.
10. `primaryCpuAbi` de Terraria se lee por reflexión (API oculta): puede mostrar "desconocida".
11. Sin pruebas instrumentadas ni instalación en Android 13 realizadas.
