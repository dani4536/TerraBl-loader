TerraBL Loader es una obra independiente. No contiene código de Bunny Loader (PolyForm Noncommercial 1.0.0,
Required Notice: Copyright (c) 2026 JonataOliveiraa, https://github.com/JonataOliveiraa/Bunny-Loader).
Usa su formato de paquetes `.bl` como referencia de compatibilidad. Si en el futuro se copia código de ese
proyecto, se debe conservar su aviso, mantener el uso no comercial y documentarlo aquí.
`testdata/arkofthecosmos.bl` es el mod entregado por el usuario (MIT según su manifiesto), sin modificar.
Terraria, Unity y sus binarios pertenecen a sus propietarios y no se incluyen.
