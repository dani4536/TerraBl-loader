# ARCHITECTURE — decisiones técnicas

Fuente de verdad del proyecto junto con PROGRESS.md y TODO.md. No dependas del historial de chat.

## D1. Gestor y motor son componentes distintos
- **Gestor (hecho, sin probar en dispositivo):** importa, valida, instala, activa/desactiva, elimina, perfiles. Kotlin puro + Compose. Sin INTERNET.
- **Motor / integración con Terraria (NO hecho):** ejecutar mods dentro del juego. Ver D4-D6.
- "Activado" en la UI significa solo "marcado para cargar"; la UI avisa de que no se ejecuta.

## D2. ARM32 real
- `abiFilters += "armeabi-v7a"` y `CMakeLists.txt` aborta si `ANDROID_ABI != armeabi-v7a`.
- El workflow CI falla si el APK contiene cualquier `.so` que no sea ELF 32-bit ARM en `lib/armeabi-v7a/`.
- Regla: nunca meter binarios arm64 (p. ej. el `libmonosgen` ARM64 de Bunny Loader) en este APK.

## D3. Paquetes .bl (verificado contra el repo original y el mod real)
- ZIP con `manifest.json` en la raíz. Discriminador: `blVersion`.
  - **2**: todo bajo `content/`, `entry` (p. ej. `main.js`) relativo a `content/`. Módulos ES con imports relativos.
  - **3**: como tModLoader: `<id>.cs` o `<id>.dll` en la raíz + `Assets/ Common/ Content/ Localization/`.
  - Otro valor/ausente: rechazado.
- Validación antes de instalar: magic `PK`, ZIP Slip/rutas absolutas/`\`/unidad/NUL, nº de entradas, tamaño por entrada y total, ratio de compresión (zip bomb), duplicados, CRC de cada archivo, manifiesto (id regex, blVersion, uid), layout por formato, imports relativos de JS.
- Instalación atómica: extraer a `staging/` (contando bytes reales escritos) → copia de seguridad si reemplaza → rename a `mods/<dir>/`. Restos de instalaciones interrumpidas se limpian al arrancar.
- Identidad: `uid` si existe, si no `id`. Duplicados: mismo SHA-256 / misma identidad y versión / otra versión.
- Los mods se instalan **desactivados**; nada se ejecuta sin acción del usuario.

## D4. Motor BL v2 (JS) — diseño, pendiente
- QuickJS (Fabrice Bellard, MIT) compilado con NDK para armeabi-v7a vía CMake (`third_party/quickjs`, aún no incluido: sandbox sin red).
- Resolución de módulos propia (`JS_SetModuleLoaderFunc`) restringida a `content/` del mod (reutiliza las reglas de `PackageValidator.resolveRelative`).
- `Mod` base con `Load()` / `PostSetupContent()`; objeto `bl` (`bl.log`, `bl.loadTexture` son los únicos usados por el mod de prueba).
- **El bloqueo real:** los mods v2 usan globals que son un *puente a clases de Terraria* (`Main`, `Player`, `ModItem`, `ModProjectile`, `SoundEngine`, `ModConfig`...). Sin hooks en el proceso del juego esos objetos no existen. QuickJS solo ejecutaría `main.js` hasta el primer `Main.x`.
- El Bunny Loader actual **eliminó** ese puente JS (historial en `docs/historico/` del repo original). La referencia de la API vieja está ahí (`referencia-js/ponte-e-bl.md`).

## D5. Runtime BL v3 (C#) — pendiente, con bloqueos
- Bunny Loader actual: Mono de `Microsoft.NETCore.App.Runtime.Mono.android-arm64` 10.0.14 (NuGet), BCL net10.0, mods compilados con Roslyn en el dispositivo, `HookGate.S`/`GuardedCall.S` en ensamblador AArch64.
- Para ARM32 habría que: (a) comprobar que existe el runtime pack Mono `android-arm` equivalente y su SHA-256; (b) reescribir todo el `.S` y `Arm64Frame.h` para ARM/Thumb-2 (AAPCS32); (c) re-validar offsets de IL2CPP en el binario ARM32 de Terraria. Nada de esto está verificado.
- Hasta entonces BL v3 se **detecta, valida e instala**, no se ejecuta.

## D6. Integración con Terraria — pendiente, depende de datos que no tengo
- Bunny Loader original aloja Unity en su propio proceso (necesita `unity-classes.jar` 2021.3.56f2, fuera de Git) y su propio documento `DECISAO-ARQUITETURA.md` marca "open": PairIP en Terraria rompe el alojamiento; opciones (A) engañar a PairIP, (B) inyección con root, (C) re-empaquetar el APK, (D) versión antigua sin PairIP.
- Nada de eso se puede decidir sin el APK ARM32 de Terraria del usuario. **No se simula.**
- El botón "Iniciar Terraria" abre el juego **sin modificar** y lo dice.

## D7. Licencia y marca (obligaciones)
- Bunny Loader: PolyForm Noncommercial 1.0.0. TerraBL deriva ideas/formatos, no copia código (aún). Si se copia código: conservar `Required Notice`, uso solo no comercial, sin anuncios ni versión de pago.
- Marca: nombre distinto (TerraBL), `applicationId` distinto, sin logo del conejo, nota "no oficial, basado en Bunny Loader" (Ajustes > Acerca de y README).
- No se distribuye ninguna biblioteca de Terraria ni de Unity.

## D8. Memoria (2 GB)
- Nada se carga entero salvo manifiesto (<256 KB) y JS (<2 MB, para comprobar imports). CRC y SHA-256 en streaming (buffers 16-32 KB).
- Límites configurables (bajo consumo): 128 MB descomprimido/paquete, 32 MB/entrada.
- Caché de importación acotada (16/64/128 MB), logs rotativos 3×128 KB, máx. 2 backups por mod, `OutOfMemoryError` capturado con mensaje al usuario.
- Carga de recursos "bajo demanda" aplica al motor futuro; hoy el gestor no carga recursos de mods.
