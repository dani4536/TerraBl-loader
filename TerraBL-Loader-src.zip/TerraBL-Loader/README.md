# TerraBL Loader

Gestor de mods `.bl` (BL v2 JavaScript / BL v3 C#) para **Terraria Mobile**, compilado solo para **Android 32 bits (`armeabi-v7a`)**.

> Proyecto **no oficial**, basado en el formato de [Bunny Loader](https://github.com/JonataOliveiraa/Bunny-Loader) (PolyForm Noncommercial 1.0.0). Uso no comercial. No incluye nada de Terraria ni de Unity.

## Estado real (leer antes de instalar)
- **Nunca se ha compilado ni probado en un dispositivo.** El APK lo genera GitHub Actions; hasta que ese build termine en verde y lo instales en tu A63Max, nada de esto está verificado. El primer build puede fallar por errores que no he podido detectar sin compilador.
- Lo que hace el APK: importar, validar, instalar, activar/desactivar, eliminar mods `.bl`, perfiles, ajustes, logs.
- Lo que **NO** hace: ejecutar mods dentro de Terraria. No hay motor JS, ni runtime C#, ni hooks. "Iniciar Terraria" abre el juego sin modificar.
- Detalle: `PROGRESS.md`, `docs/LIMITATIONS.md`, `docs/COMPATIBILITY.md`.

## Compilar el APK desde el teléfono (GitHub Actions)

GitHub no descomprime ZIPs al subirlos desde el móvil, así que el workflow sabe compilar **directamente desde el ZIP** subido a la raíz del repo.

1. Entra a **github.com** desde el navegador del móvil (inicia sesión; si no tienes cuenta, créala). Mejor activar "Sitio de escritorio" en el menú del navegador.
2. **New repository** → nombre `TerraBL-Loader` → *Private* o *Public* → marca *Add a README* → **Create repository**.
3. En el repo: **Add file → Upload files** → elige `TerraBL-Loader-src.zip` (el ZIP tal cual, sin descomprimir) → **Commit changes**.
4. **Add file → Create new file**. En el campo de nombre escribe exactamente:
   `.github/workflows/build.yml`
   (al escribir cada `/` se crea la carpeta). Pega dentro el contenido de la sección **"Workflow"** de más abajo. **Commit changes**.
5. Ese commit lanza la compilación solo. También puedes ir a **Actions → Build TerraBL Loader (ARM32) → Run workflow**.
6. Espera ~10-20 min. Abre la ejecución:
   - Verde: baja a **Artifacts** y descarga `TerraBL-Loader-APK-armeabi-v7a` (es un ZIP con los APK; el gestor de archivos de Android lo abre), **o** ve a **Releases** (`apk-N`) y descarga el `.apk` directo.
   - Rojo: abre el paso en rojo, copia las últimas ~40 líneas del log y pásaselas a Claude. Ya está previsto que el fallo sea posible.
7. Instala `TerraBL-Loader-debug-armeabi-v7a.apk` (usa el *debug* primero). Permite "instalar apps desconocidas" para tu navegador/gestor de archivos.
8. Abre la app → Inicio: debe decir núcleo nativo `armeabi-v7a`, 32 bits. Si ahí aparece otra cosa, avísame.
9. Archivos → elige `arkofthecosmos.bl` (en el ZIP, carpeta `testdata/`; extráelo con el gestor de archivos) → revisa el informe → Instalar. Esto solo **instala**; no ejecuta el mod.

Si prefieres subir el proyecto descomprimido (desde un PC), sube la carpeta completa con su `.github/` y el workflow funciona igual.

## Qué verifica el workflow
Preflight de configuración → `gradle assembleDebug assembleRelease` (AGP 8.5.2, Gradle 8.7, Kotlin 1.9.24, SDK 34, NDK 26.1.10909125, CMake 3.22.1) → comprueba que todo `.so` del APK es **ELF 32-bit ARM** en `lib/armeabi-v7a/` y que no hay otra ABI → publica artefacto y Release → tests JVM (informativos: si fallan no bloquean el APK).

El APK *release* está firmado con la clave de depuración: solo para uso propio.

## Compilar en local
JDK 17, Android SDK 34, NDK 26.1.10909125, CMake 3.22.1, Gradle 8.7: `gradle :app:assembleDebug`. Ver `docs/BUILD.md`.

## Documentos
`PROGRESS.md` (estado) · `TODO.md` · `ARCHITECTURE.md` · `docs/COMPATIBILITY.md` · `docs/LIMITATIONS.md` · `docs/BUILD.md` · `NOTICE.md`

## Workflow
Contenido exacto de `.github/workflows/build.yml` (también incluido en el ZIP):

```yaml
name: Build TerraBL Loader (ARM32)

on:
  workflow_dispatch:
  push:
    branches: [main, master]

permissions:
  contents: write

concurrency:
  group: build-${{ github.ref }}
  cancel-in-progress: true

jobs:
  build:
    runs-on: ubuntu-latest
    timeout-minutes: 45
    steps:
      - uses: actions/checkout@v4

      # Acepta dos disposiciones del repo: proyecto descomprimido, o solo un .zip en la raiz.
      - name: Localizar proyecto
        id: p
        run: |
          if [ -f settings.gradle.kts ]; then
            d=.
          else
            z=$(ls -1 *.zip 2>/dev/null | head -1 || true)
            [ -n "$z" ] || { echo "::error::No hay settings.gradle.kts ni un .zip en la raiz del repositorio"; exit 1; }
            unzip -q -o "$z" -d _src
            s=$(find _src -name settings.gradle.kts | head -1)
            [ -n "$s" ] || { echo "::error::El .zip no contiene settings.gradle.kts"; exit 1; }
            d=$(dirname "$s")
          fi
          echo "Proyecto en: $d"
          echo "dir=$d" >> "$GITHUB_OUTPUT"

      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "17"

      - name: Instalar plataforma, NDK y CMake
        run: |
          SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
          yes | "$SDKM" --licenses > /dev/null || true
          "$SDKM" "platforms;android-34" "build-tools;34.0.0" "ndk;26.1.10909125" "cmake;3.22.1"

      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: "8.7"

      - name: Preflight (configuracion; no es una compilacion)
        working-directory: ${{ steps.p.outputs.dir }}
        run: python3 tools/preflight.py

      - name: Compilar APK debug y release (armeabi-v7a)
        working-directory: ${{ steps.p.outputs.dir }}
        run: gradle :app:assembleDebug :app:assembleRelease --no-daemon --stacktrace

      - name: Verificar ABI (solo armeabi-v7a, ELF ARM 32 bits)
        working-directory: ${{ steps.p.outputs.dir }}
        run: |
          set -e
          for apk in app/build/outputs/apk/debug/*.apk app/build/outputs/apk/release/*.apk; do
            echo "== $apk"
            libs=$(unzip -Z1 "$apk" | grep '^lib/' | grep -v '/$' || true)
            echo "$libs"
            echo "$libs" | grep -qx 'lib/armeabi-v7a/libterrabl.so' || { echo "::error::falta libterrabl.so ARM32 en $apk"; exit 1; }
            if echo "$libs" | grep -v '^lib/armeabi-v7a/' | grep -q .; then echo "::error::hay bibliotecas de otra ABI en $apk"; exit 1; fi
            rm -rf /tmp/x && mkdir -p /tmp/x && unzip -q "$apk" 'lib/armeabi-v7a/*.so' -d /tmp/x
            for so in /tmp/x/lib/armeabi-v7a/*.so; do
              out=$(file "$so"); echo "$out"
              echo "$out" | grep -q 'ELF 32-bit' && echo "$out" | grep -q 'ARM' || { echo "::error::$so no es ELF ARM 32 bits"; exit 1; }
            done
          done

      - name: Reunir APKs
        working-directory: ${{ steps.p.outputs.dir }}
        run: |
          mkdir -p dist
          cp app/build/outputs/apk/debug/*.apk   dist/TerraBL-Loader-debug-armeabi-v7a.apk
          cp app/build/outputs/apk/release/*.apk dist/TerraBL-Loader-release-armeabi-v7a.apk
          (cd dist && sha256sum *.apk | tee SHA256SUMS.txt)

      - name: Publicar artefacto descargable
        uses: actions/upload-artifact@v4
        with:
          name: TerraBL-Loader-APK-armeabi-v7a
          path: ${{ steps.p.outputs.dir }}/dist/*
          if-no-files-found: error

      # Enlace directo al .apk (sin ZIP) en la pestana Releases: mas comodo desde el movil.
      - name: Publicar en Releases (APK directo)
        continue-on-error: true
        env:
          GH_TOKEN: ${{ github.token }}
        run: |
          gh release create "apk-${{ github.run_number }}" ${{ steps.p.outputs.dir }}/dist/*.apk \
            --target "${{ github.sha }}" --prerelease \
            --title "TerraBL Loader build ${{ github.run_number }} (armeabi-v7a, SIN PROBAR)" \
            --notes "APK ARM32 compilado por GitHub Actions. No probado en dispositivo. Solo gestor de paquetes .bl; no inyecta mods en Terraria."

      # Informativo: el codigo nunca se ha ejecutado, un test fallido no debe impedir tener el APK.
      - name: Tests unitarios JVM (informativo)
        continue-on-error: true
        working-directory: ${{ steps.p.outputs.dir }}
        run: gradle :app:testDebugUnitTest --no-daemon
```
