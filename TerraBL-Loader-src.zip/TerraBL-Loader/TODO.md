# TODO (orden de prioridad)

## 1. APK ARM32 instalable
- [ ] Ejecutar CI (README) y corregir errores de compilación (Kotlin/CMake/Gradle); pegar el log aquí
- [ ] Icono de launcher propio (NO usar el conejo de Bunny Loader)
- [ ] Añadir `gradle/wrapper` real
- [ ] Probar instalación en Android 13 ARM32
## 2-3. Interfaz y gestor
- [ ] Probar importación del `.bl` real en dispositivo; medir RAM
- [ ] Exportar/restaurar backups desde la UI
- [ ] Ver README/descripción de cada mod (hoy solo resumen)
- [ ] Localización (es/en)
## 4. Manifiestos
- [ ] Soportar `type` texture/font y `dependencies` con orden de carga
## 5. Motor JS BL v2
- [ ] Vendorizar QuickJS (MIT) en `third_party/quickjs`, compilar ARM32
- [ ] Module loader restringido a `content/`; clase base `Mod`; `bl.log`, `bl.loadTexture`
- [ ] Ejecutar `main.js` del mod real hasta el primer global de Terraria (prueba sin juego)
## 6. Runtime C# BL v3
- [ ] Verificar existencia/hash de runtime Mono android-arm; decidir Mono vs alternativa
- [ ] Portar `HookGate.S`/`GuardedCall.S` a ARM/Thumb-2
## 7. Integración Terraria (BLOQUEADO por datos del usuario)
- [ ] Obtener ABI real de Terraria (Inicio la muestra)
- [ ] Elegir ruta A/B/C/D de ARCHITECTURE D6
- [ ] Hook engine ARMv7, IL2CPP bridge, Content Registry, Asset Manager, Mod Bridge
## 8. Optimización
- [ ] Medir consumo en MT6739/2 GB
